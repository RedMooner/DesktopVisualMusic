
var editMode = false;
var bodyNode = document.body;
//const  {ipcRenderer_1} = require('electron');

